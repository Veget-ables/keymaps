#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
class ${NAME} : ${INHERIT_VIEW} {
 constructor(context: Context) : super(context)

 constructor(context: Context, attrs: AttributeSet) : super(context, attrs)

 constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr)
}

